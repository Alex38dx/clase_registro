<?php

$usuario = $_POST["usuario"];
$contraseña = $_POST["contraseña"];

if ($usuario == "itfip" && $contraseña == "2024") {
    echo "Inicio sesion correctamente";
} else {
    echo "Usuario o contrasena incorrectos";
}

?>
