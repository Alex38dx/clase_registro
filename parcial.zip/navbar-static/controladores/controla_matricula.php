<?php

$matricula = $_POST["matricula"];
$documento = $_POST["documento"];



echo "Te has matriculado a: " . $matricula . "<br>";
echo "Documento: " . $documento;
?>
