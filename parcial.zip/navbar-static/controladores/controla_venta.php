<?php
$valor = $_POST["valor"];
$edad = $_POST["edad"];
if($edad <=0)
{
    die("edad no validad");
}
if($valor <=0)
{
    die("valor no valido");
}

if($edad >= 60) 
{
    $des = $valor * 0.2;
    $total = $valor - $des;
    echo $total;

}else{
  echo  $valor;
}


?>