<?php

$age = $_POST["age"];
$password = $_POST["password"];
$password2 = $_POST["password2"];

$verifiqued = ($password == $password2);

if($age >= 18 && $verifiqued ){

    echo " great you verifiqued";
}else {
    echo "error not verifiqued";
}if($age <= 0){
    echo "error age no valid";
}




?>

