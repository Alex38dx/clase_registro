<?php
$valor = $_POST["valor"];

if($valor <=0)
{
    die("cantidad no validad");
}else

{
  echo "la cantidad de mascotas recibidas es de". $valor;
}


?>