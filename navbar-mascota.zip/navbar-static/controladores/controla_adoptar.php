<?php
$nombre = $_POST["nombre"];
$raza =$_POST["raza"];
$edad =$_POST["edad"];

if($edad <=21)
{
    die("muy joven para adoptar");
}else{

  echo $nombre." - ".$edad." - ".$raza ;
  
}



?>