<?php
$nombre =$_POST["nombre"];
$raza =$_POST["raza"];


{

echo $nombre." - ".$raza;
}
?>