<nav class="navbar navbar-expand-md navbar-dark bg-dark mb-4">
  <div class="container-fluid">
<nav class="d-inline-flex mt-2 mt-md-0 ms-md-auto">
        <a class="me-3 py-2 link-body-emphasis text-decoration-none" href="index.php">Inicio</a>
        <a class="me-3 py-2 link-body-emphasis text-decoration-none" href="crear.php">Crear mascotas</a>
        <a class="me-3 py-2 link-body-emphasis text-decoration-none" href="recibir.php">Recibir mascotas</a>
        <a class="me-3 py-2 link-body-emphasis text-decoration-none" href="adoptar.php">Adoptar mascota</a>
      </nav>
</div>