<?php
$nombre =$_POST["nombre"];
$documento =$_POST["docu"];
$edad =$_POST["edad"];
if($edad >=18)
{
    // si entra aca es mayor de edad
 echo "tome guaro <br>";
}else{
    // si entra aca es menor de edad
 echo "vayase pa casa <br>";
}

echo $nombre." - ".$documento." - ".$edad;
?>