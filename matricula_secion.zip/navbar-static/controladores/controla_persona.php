<?php

$nombre = $_POST["nombre"];
$apellido = $_POST["apellido"];
$telefono = $_POST["telefono"];
$correo = $_POST["correo"];
$estrato = $_POST["estrato"];
$estimulo = $_POST["estimulo"];


if ($estrato <= 3 && $estimulo == "si") {
    $estimulo_otorgado = true;
} else {
    $estimulo_otorgado = false;
}

echo "Persona registrada: " . $nombre . " " . $apellido . "<br>";
echo "Teléfono: " . $telefono . "<br>";
echo "Correo: " . $correo . "<br>";
echo "Estrato: " . $estrato . "<br>";

if ($estimulo_otorgado) {
    echo "El estimulo ha sido otorgado.";
} else {
    echo "No se otorga el estimulo.";
}

?>

