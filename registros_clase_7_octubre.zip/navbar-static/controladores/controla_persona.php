<?php

$nombre = $_POST["nombre"];
$apellido = $_POST["apellido"];
$telefono = $_POST["telefono"];
$correo = $_POST["correo"];
$estrato = $_POST["estrato"];
$estimulo = isset($_POST["estimulo"]) ? true : false;

echo "Persona registrada: " . $nombre . " " . $apellido . "<br>";
echo "Telefono: " . $telefono . "<br>";
echo "Correo: " . $correo . "<br>";
echo "Estrato: " . $estrato . "<br>";

if ($estimulo && $estrato <= 3) {
    echo "Felicidades, $nombre $apellido. usted es elegible para el estimulo";
} elseif ($estimulo && $estrato > 3) {
    echo "Lo sentimos, $nombre $apellido. no es elegible para solicitar el estimulo por su estrato";
} else {
    echo "la persona, $nombre $apellido. no ha solicitado estimulo educativo ";
}


?>

